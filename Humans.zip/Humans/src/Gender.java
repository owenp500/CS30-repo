
public enum Gender {
	MALE,
	FEMALE,
	NON_BINARY,
	GENDER_FLUID,
	OTHER
}
